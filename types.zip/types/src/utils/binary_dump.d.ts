export declare function dumpBuffer(src: Uint8Array): string;
