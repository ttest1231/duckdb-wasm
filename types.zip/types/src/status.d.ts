export declare enum StatusCode {
    SUCCESS = 0
}
