/** Register the worker */
export declare function registerWorker(): void;
