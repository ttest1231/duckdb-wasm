export declare const PACKAGE_NAME: string;
export declare const PACKAGE_VERSION: string;
export declare const PACKAGE_VERSION_MAJOR: string;
export declare const PACKAGE_VERSION_MINOR: string;
export declare const PACKAGE_VERSION_PATCH: string;
