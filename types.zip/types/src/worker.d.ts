export declare function createWorker(url: string): Promise<Worker>;
