import * as duckdb from '../src/';
export declare function testJSON(db: () => duckdb.DuckDBBindings): void;
