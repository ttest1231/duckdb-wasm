import * as duckdb from '../src/';
export declare function testTokenization(db: () => duckdb.DuckDBBindings): void;
export declare function testTokenizationAsync(db: () => duckdb.AsyncDuckDB): void;
