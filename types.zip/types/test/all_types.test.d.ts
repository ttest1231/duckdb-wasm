import * as duckdb from '../src/';
export declare function testAllTypes(db: () => duckdb.DuckDBBindings): void;
export declare function testAllTypesAsync(db: () => duckdb.AsyncDuckDB): void;
