import * as duckdb from '../src/';
export declare function testAsyncBatchStream(db: () => duckdb.AsyncDuckDB): void;
