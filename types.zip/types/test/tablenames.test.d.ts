import * as duckdb from '../src/';
export declare function testTableNames(db: () => duckdb.DuckDBBindings): void;
export declare function testTableNamesAsync(db: () => duckdb.AsyncDuckDB): void;
