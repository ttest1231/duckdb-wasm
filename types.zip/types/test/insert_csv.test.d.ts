import * as duckdb from '../src/';
export declare function testCSVInsert(db: () => duckdb.DuckDBBindings): void;
export declare function testCSVInsertAsync(db: () => duckdb.AsyncDuckDB): void;
