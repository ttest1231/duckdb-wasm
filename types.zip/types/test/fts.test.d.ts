import * as duckdb from '../src/';
export declare function testFTS(db: () => duckdb.DuckDBBindings): void;
