import * as duckdb from '../../src';
export declare function test477(db: () => duckdb.AsyncDuckDB): void;
