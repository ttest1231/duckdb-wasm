import * as duckdb from '../../src';
export declare function test334(adb: () => duckdb.AsyncDuckDB): void;
