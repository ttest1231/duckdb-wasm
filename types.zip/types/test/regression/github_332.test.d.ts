import * as duckdb from '../../src';
export declare function test332(db: () => duckdb.AsyncDuckDB): void;
