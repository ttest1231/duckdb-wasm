import * as duckdb from '../../src';
export declare function test448(db: () => duckdb.AsyncDuckDB): void;
