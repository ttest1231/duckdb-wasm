import * as duckdb from '../../src';
export declare function test470(db: () => duckdb.AsyncDuckDB): void;
