import * as duckdb from '../../src/';
export declare function testRegressionAsync(adb: () => duckdb.AsyncDuckDB): void;
