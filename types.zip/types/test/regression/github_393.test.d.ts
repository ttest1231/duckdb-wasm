import * as duckdb from '../../src';
export declare function test393(db: () => duckdb.AsyncDuckDB): void;
