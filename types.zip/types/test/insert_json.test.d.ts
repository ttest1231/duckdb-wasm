import * as duckdb from '../src/';
export declare function testJSONInsert(db: () => duckdb.DuckDBBindings): void;
export declare function testJSONInsertAsync(db: () => duckdb.AsyncDuckDB): void;
