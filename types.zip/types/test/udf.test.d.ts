import * as duckdb from '../src/';
export declare function testUDF(db: () => duckdb.DuckDBBindings): void;
