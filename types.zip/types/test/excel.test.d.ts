import * as duckdb from '../src/';
export declare function testEXCEL(db: () => duckdb.DuckDBBindings): void;
