import * as duckdb from '../src/';
export declare function testBatchStream(db: () => duckdb.DuckDBBindings): void;
